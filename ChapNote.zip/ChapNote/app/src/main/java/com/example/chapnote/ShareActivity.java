package com.example.chapnote;

import android.support.v7.app.AppCompatActivity;

public class ShareActivity extends AppCompatActivity {
}
