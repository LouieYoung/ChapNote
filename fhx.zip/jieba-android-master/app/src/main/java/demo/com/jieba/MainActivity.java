package demo.com.jieba;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.zhy.view.flowlayout.FlowLayout;
import com.zhy.view.flowlayout.TagAdapter;
import com.zhy.view.flowlayout.TagFlowLayout;

import java.util.ArrayList;

import jackmego.com.jieba_android.JiebaSegmenter;

public class MainActivity extends AppCompatActivity {
    private Button btn;
    private EditText editText;
    private TextView textView;
    private TextView textView2;

    private MyDataBaseHelper dbHelper;//= new MyDataBaseHelper(this,"mymoney1.db",null,1);
    private SQLiteDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper= new MyDataBaseHelper(this,"mymoney3.db",null,1);
        db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put("text","我在哈尔滨工业大学威海");
        values.put("id",1);
        db.insert("note",null,values);
        values.clear();

        values.put("text","我爱哈尔滨大连");
        values.put("id","2");
        db.insert("note",null,values);
        values.clear();

        values.put("text","城市戴尔什么东西");
        values.put("id","3");
        db.insert("note",null,values);
        values.clear();

        btn = findViewById(R.id.btn);
        editText = findViewById(R.id.editText);
        textView = findViewById(R.id.textView);
        textView2 = findViewById(R.id.textView2);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ArrayList<String> wordList = JiebaSegmenter.getJiebaSegmenterSingleton().getDividedString(editText.getText().toString());
                String ss = "";
                for(int i=0;i<wordList.size();i++){
                    ss = ss+String.valueOf(wordList.get(i))+",";
                }
                textView2.setText(ss);

                ArrayList al = searchAll();
                String s="";
                if(!al.isEmpty()){
                    for(int i=0;i<al.size();i++){
                        s = s+String.valueOf(al.get(i))+",";

                    }
                }

                textView.setText(s);
            }
        });
    }

    public ArrayList searchAll(){
        ArrayList<String> wordList = JiebaSegmenter.getJiebaSegmenterSingleton().getDividedString(editText.getText().toString().trim());
        ArrayList arrayList1 = search(wordList.get(0));
        ArrayList arrayList3;
        for(int i=0;i<wordList.size()-1;i++){
            ArrayList arrayList2 = search(wordList.get(i+1));
            arrayList3 = forSame(arrayList1,arrayList2);
            if(arrayList3.isEmpty()){
                arrayList1.clear();
                break;
            }
            arrayList1.clear();
            arrayList1 = (ArrayList) arrayList3.clone();
            arrayList3.clear();
        }
        return arrayList1;

    }

    public ArrayList search(String s){
        Cursor cursor = db.query("note", null, null, null, null, null, null);
        ArrayList arrayList = new ArrayList();
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndex("id"));
                String tag = cursor.getString(cursor.getColumnIndex("text"));
                if(tag.indexOf(s)!=-1)
                {
                    arrayList.add(id);
                }
            } while (cursor.moveToNext());
        }
        cursor.close();
        return arrayList;
    }
    public ArrayList forSame(ArrayList a,ArrayList b){
        ArrayList arrayList3 = new ArrayList();
        for(int j=0;j<a.size();++j){
            if(b.contains(a.get(j))){
                arrayList3.add(a.get(j));
            }
        }
        return arrayList3;
    }

}
